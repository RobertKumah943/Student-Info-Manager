import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() => runApp(const StudentInfoApp());

class StudentInfoApp extends StatelessWidget {
  const StudentInfoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Info Manager App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 216, 13, 16)),
        useMaterial3: true,
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: const StudentInfoHome(),
    );
  }
}

class StudentInfoHome extends StatefulWidget {
  const StudentInfoHome({super.key});
  @override
  State<StudentInfoHome> createState() => _StudentInfoHomeState();
}

class _StudentInfoHomeState extends State<StudentInfoHome> {
  int _studentCount = 0;

  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _pwdCtrl = TextEditingController();

  @override
  void dispose() {
    _emailCtrl.dispose();
    _pwdCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final spacer = const SizedBox(height: 16);

    return Scaffold(
      appBar: AppBar(title: const Text('Student Information Manager App')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // (a) Welcome Dashboard
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                colors: [Theme.of(context).colorScheme.primaryContainer, Colors.white],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: const [BoxShadow(blurRadius: 8, spreadRadius: 1, color: Colors.black12)],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('KUMAH ROBERT',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text('Course: BSc IT'),
              Text('University: UENR'),
            ]),
          ),

          spacer,

          // (b) Interactive Notification (Snackbar)
          ElevatedButton.icon(
            icon: const Icon(Icons.notifications),
            label: const Text('Show Alert'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  behavior: SnackBarBehavior.floating,
                  content: Text('Hello, Brandon! Welcome to the Student Info Manager.'),
                ),
              );
            },
          ),

          spacer,

          // (c) Student Counter
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text('Students Enrolled', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                Text('$_studentCount', style: Theme.of(context).textTheme.displaySmall),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline, size: 32),
                    onPressed: () => setState(() => _studentCount = (_studentCount - 1).clamp(0, 100000)),
                  ),
                  const SizedBox(width: 24),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline, size: 32),
                    onPressed: () => setState(() => _studentCount++),
                  ),
                ]),
              ]),
            ),
          ),

          spacer,

          // (d) Student Login Form + validation
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text('Student Login', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email', prefixIcon: Icon(Icons.email), border: OutlineInputBorder(),
                    ),
                    validator: (v) {
                      if (v == null || v.isEmpty) return 'Email is required';
                      if (!v.contains('@')) return 'Email must contain @';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _pwdCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder(),
                    ),
                    validator: (v) {
                      if (v == null || v.isEmpty) return 'Password is required';
                      if (v.length < 6) return 'Password must be at least 6 characters';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Login successful!')),
                        );
                      }
                    },
                    child: const Text('Login'),
                  ),
                ]),
              ),
            ),
          ),

          spacer,

          // (e) Profile Picture Display
          Text('Profile Picture', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          AspectRatio(
            aspectRatio: 16 / 9,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                'https://th.bing.com/th/id/OIP.aZSjAgenOJqUzAum5QlWYAHaE8?w=280&h=187&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image)),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
