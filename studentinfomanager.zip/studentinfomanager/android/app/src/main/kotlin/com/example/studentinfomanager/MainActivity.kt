package com.example.studentinfomanager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
